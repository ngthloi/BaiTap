package bttuan5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bttuan41Application {

	public static void main(String[] args) {
		SpringApplication.run(Bttuan41Application.class, args);
	}

}
