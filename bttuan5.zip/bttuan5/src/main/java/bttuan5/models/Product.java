package bttuan5.models;

import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Product {
	private int id;
	@NotBlank(message = "Tên sản phẩm k đc để trống")
	private String name;
	@Length(min = 0, max = 50, message = "Tên hình ảnh k quá 50 kí tự")
	private String image;
	@NotNull(message = "giá sản phẩm k đc để trống")
	@Min(value = 1, message = "Giá sản phẩm l đc nhỏ hơn 1")
	@Max(value = 99999999, message = "giá sản phẩm k đc lớn hơn 99999999")
	private long price;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

}
