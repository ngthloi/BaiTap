package bttuan6.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import bttuan6.Model.Product;
import bttuan6.Repository.ProductRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository repo;


    public List<Product> Getall(){
        return (List<Product>) repo.findAll();
    }
    public void add(Product newProduct){ repo.save(newProduct);}
    public void edit( Product editProduct) {

      repo.save(editProduct);
    }
    public Product getProductById(Integer id){

        return repo.findById(id).orElse(null);
    }
    public void delete(Product deleteProduct){
        repo.delete(deleteProduct);
    }
}
