package bttuan6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class bttuan6Application {

	public static void main(String[] args) {
		SpringApplication.run(bttuan6Application.class, args);
	}

}
