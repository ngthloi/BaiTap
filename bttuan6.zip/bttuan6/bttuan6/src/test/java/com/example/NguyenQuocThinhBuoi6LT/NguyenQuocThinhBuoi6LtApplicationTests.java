package com.example.NguyenQuocThinhBuoi6LT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NguyenQuocThinhBuoi6LtApplicationTests {

	@Test
	void contextLoads() {
	}

}
